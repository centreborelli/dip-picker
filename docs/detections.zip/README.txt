# Data from the paper: A contrario dip picking for borehole imaging

```
A contrario dip picking for borehole imaging.
J. Costes, G. Facciolo, R. Grompone von Gioi, J. Kherroubi, E. Meinhardt-Llopis, and J.-M. Morel. 
SEG Geophysics, 2021. https://cmla.github.io/dip-picker/
``` 


This zip contains the output of the automatic detection algorithm applied on 
the three borehole images available at: https://cmla.github.io/dip-picker/.
A notebook to visualize the annotations and the detected dips is provided:

'dipViewer.ipynb' : loads and visualize annotated dips along with the automatic detections

The notebook requires that the files with automatic dip detections are present
Download and unzip the three files annotated boreholes in the current directory.
     https://github.com/cmla/dip-picker/blob/master/docs/48_19a-c2.zip 
     https://github.com/cmla/dip-picker/blob/master/docs/48_19a-c3.zip 
     https://github.com/cmla/dip-picker/blob/master/docs/48_19a-c4.zip 


The output of the automatic detection has one line per detected dip and 
has 6 columns with the following format
>    phi1 phi2 depth orientation nfa octave


The datasets: fist column is the image, the second is the manual annotation, the third is the base of the automatic annotation
       ('./48-19a-c4/48_19a-C4_6_in_Section_Ream_Down_3B.csv',  './48-19a-c4/48_19a-C4_DipJK.csv',     'out_dips_c4_ms_sigma1_ref100.txt'), 
       ('./48-19a-c3/48_19a-C3_Run 10 Washdown_3B.csv',         './48-19a-c3/48_19a-C3_DipJK.csv',     'out_dips_c3_ms_sigma1_ref100.txt'), 
       ('./48-19a-c2/48_19a-C2_Ream Up 3_3B.csv',               './48-19a-c2/48_19a-C2_DipJK.csv',     'out_dips_c2_ms_sigma1_ref100.txt')

